class Dropout(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.dropout.___torch_mangle_1028.Dropout,
    argument_1: Tensor) -> Tensor:
    input = torch.dropout_(argument_1, 0.20000000000000001, False)
    return input
