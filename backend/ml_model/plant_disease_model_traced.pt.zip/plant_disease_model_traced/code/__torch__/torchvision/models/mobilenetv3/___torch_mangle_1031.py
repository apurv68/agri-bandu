class MobileNetV3(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  features : __torch__.torch.nn.modules.container.___torch_mangle_1024.Sequential
  avgpool : __torch__.torch.nn.modules.pooling.___torch_mangle_1025.AdaptiveAvgPool2d
  classifier : __torch__.torch.nn.modules.container.___torch_mangle_1030.Sequential
  def forward(self: __torch__.torchvision.models.mobilenetv3.___torch_mangle_1031.MobileNetV3,
    x: Tensor) -> Tensor:
    classifier = self.classifier
    avgpool = self.avgpool
    features = self.features
    _0 = (avgpool).forward((features).forward(x, ), )
    input = torch.flatten(_0, 1)
    return (classifier).forward(input, )
