class InvertedResidual(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  block : __torch__.torch.nn.modules.container.___torch_mangle_942.Sequential
  def forward(self: __torch__.torchvision.models.mobilenetv3.___torch_mangle_943.InvertedResidual,
    argument_1: Tensor) -> Tensor:
    block = self.block
    return (block).forward(argument_1, )
